"""
incus_manager.py - thin async wrapper around the `incus` CLI for
managing LXC containers on the host DracoHost runs on.

All commands are executed with asyncio.create_subprocess_exec so the
Discord bot's event loop is never blocked. This module intentionally
shells out to the official `incus` client rather than talking to the
Incus API directly, since the CLI is already authenticated on the host
via the local unix socket.
"""

import asyncio
import secrets
import string


class IncusError(RuntimeError):
    pass


# Map friendly OS choices shown in the Reinstall dropdown to Incus image aliases.
OS_IMAGES = {
    "Ubuntu 24.04": "images:ubuntu/24.04",
    "Ubuntu 22.04": "images:ubuntu/22.04",
    "Ubuntu 20.04": "images:ubuntu/20.04",
    "Debian 13": "images:debian/13",
    "Debian 12": "images:debian/12",
    "Debian 11": "images:debian/11",
}

POST_DEPLOY_CMD = "apt update -y && apt install -y nano tmate openssh-server curl wget sudo"


def generate_password(length: int = 16) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


async def _run(*args: str, timeout: int = 120) -> str:
    """Run an incus CLI command and return stdout, raising IncusError on failure."""
    proc = await asyncio.create_subprocess_exec(
        "incus", *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise IncusError(f"Command timed out: incus {' '.join(args)}")

    if proc.returncode != 0:
        raise IncusError(stderr.decode().strip() or f"incus {' '.join(args)} failed")
    return stdout.decode().strip()


async def _exec_in_container(name: str, command: str, timeout: int = 120) -> str:
    return await _run("exec", name, "--", "bash", "-c", command, timeout=timeout)


class IncusManager:
    """High level operations used by the Discord cogs."""

    def __init__(self, network: str = "incusbr0", storage_pool: str = "default"):
        self.network = network
        self.storage_pool = storage_pool

    async def create_vps(self, name: str, ram_mb: int, cpu_cores: int, disk_gb: int,
                          os_image: str = "images:ubuntu/24.04") -> str:
        """Launch a new LXC container, apply resource limits and run base setup.
        Returns the generated root password."""
        await _run(
            "launch", os_image, name,
            "--network", self.network,
            "--storage", self.storage_pool,
            timeout=180,
        )
        await self.set_limits(name, ram_mb, cpu_cores, disk_gb)

        # Wait for networking to come up inside the container.
        for _ in range(15):
            await asyncio.sleep(2)
            try:
                out = await _run("list", name, "--format", "csv", "-c", "4")
                if out and "eth0" in out:
                    break
            except IncusError:
                continue

        await _exec_in_container(name, POST_DEPLOY_CMD, timeout=180)

        password = generate_password()
        await _exec_in_container(name, f"echo 'root:{password}' | chpasswd")
        return password

    async def set_limits(self, name: str, ram_mb: int, cpu_cores: int, disk_gb: int):
        await _run("config", "set", name, "limits.memory", f"{ram_mb}MB")
        await _run("config", "set", name, "limits.cpu", str(cpu_cores))
        try:
            await _run("config", "device", "override", name, "root",
                       f"size={disk_gb}GB")
        except IncusError:
            # Device may not exist yet (e.g. first-time set); add it instead.
            await _run("config", "device", "add", name, "root", "disk",
                       "path=/", f"pool={self.storage_pool}", f"size={disk_gb}GB")

    async def delete_vps(self, name: str):
        try:
            await _run("stop", name, "--force")
        except IncusError:
            pass  # already stopped
        await _run("delete", name, "--force")

    async def rename_vps(self, old_name: str, new_name: str):
        await _run("rename", old_name, new_name)

    async def start(self, name: str):
        await _run("start", name)

    async def stop(self, name: str):
        await _run("stop", name, "--force")

    async def restart(self, name: str):
        await _run("restart", name, "--force")

    async def suspend(self, name: str):
        """Suspend = freeze the container so the user cannot use it."""
        await _run("pause", name)

    async def unsuspend(self, name: str):
        await _run("start", name)

    async def get_ip(self, name: str) -> str | None:
        try:
            out = await _run(
                "list", name, "--format", "csv", "-c", "4"
            )
            # csv column 4 looks like "eth0 inet 10.0.0.5 (eth0)"
            for line in out.splitlines():
                if "inet " in line and "inet6" not in line:
                    parts = line.split()
                    idx = parts.index("inet")
                    return parts[idx + 1]
        except IncusError:
            return None
        return None

    async def reinstall(self, name: str, ram_mb: int, cpu_cores: int, disk_gb: int,
                         os_image: str) -> str:
        """Delete and recreate the container with a fresh OS image, keeping the name."""
        await self.delete_vps(name)
        return await self.create_vps(name, ram_mb, cpu_cores, disk_gb, os_image)

    async def regenerate_ssh(self, name: str) -> tuple[str, str]:
        """Reset root password and open a tmate session.
        Returns (new_password, tmate_ssh_string)."""
        new_password = generate_password()
        await _exec_in_container(name, f"echo 'root:{new_password}' | chpasswd")

        # Ensure tmate is installed.
        await _exec_in_container(
            name,
            "command -v tmate >/dev/null 2>&1 || (apt update -y && apt install -y tmate)",
            timeout=180,
        )

        # Kill any previous session, start a fresh detached one, then read the SSH string.
        await _exec_in_container(
            name,
            "tmate kill-session -t dracohost 2>/dev/null; "
            "tmate -S /tmp/dracohost.sock new-session -d -s dracohost && "
            "tmate -S /tmp/dracohost.sock wait tmate-ready",
            timeout=60,
        )
        tmate_ssh = await _exec_in_container(
            name,
            "tmate -S /tmp/dracohost.sock display -p '#{tmate_ssh}'",
            timeout=30,
        )
        return new_password, tmate_ssh

    async def is_running(self, name: str) -> bool:
        try:
            out = await _run("list", name, "--format", "csv", "-c", "s")
            return out.strip().upper() == "RUNNING"
        except IncusError:
            return False
