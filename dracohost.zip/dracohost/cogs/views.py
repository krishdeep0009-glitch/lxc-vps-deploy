import discord

import config
from incus_manager import IncusManager, OS_IMAGES, IncusError


def vps_embed(row, title_prefix="VPS") -> discord.Embed:
    status_emoji = {"active": "🟢", "suspended": "🟠", "expired": "🔴"}.get(
        row["status"], "⚪"
    )
    embed = discord.Embed(
        title=f"{title_prefix}: {row['name']}",
        color=config.EMBED_COLOR,
    )
    embed.add_field(name="Status", value=f"{status_emoji} {row['status'].title()}", inline=True)
    embed.add_field(name="Owner", value=f"<@{row['owner_id']}>", inline=True)
    embed.add_field(name="OS", value=row["os_image"], inline=True)
    embed.add_field(name="CPU", value=f"{row['cpu_cores']} vCPU ({config.CPU_LABEL})", inline=True)
    embed.add_field(name="RAM", value=f"{row['ram_mb']} MB", inline=True)
    embed.add_field(name="Disk", value=f"{row['disk_gb']} GB", inline=True)
    embed.add_field(name="IP Address", value=row["ip_address"] or "Not assigned", inline=True)
    embed.add_field(name="Expires", value=row["expires_at"] or "Never", inline=True)
    embed.add_field(name="Virtualization", value=config.VIRT_LABEL, inline=True)
    embed.set_footer(text=config.BRAND_NAME)
    return embed


class OSSelect(discord.ui.Select):
    def __init__(self, vps_name: str):
        self.vps_name = vps_name
        options = [discord.SelectOption(label=label) for label in OS_IMAGES.keys()]
        super().__init__(placeholder="Select an OS to reinstall...", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        label = self.values[0]
        image = OS_IMAGES[label]

        row = await bot.db.get_vps(self.vps_name)
        if row is None:
            await interaction.followup.send("❌ VPS no longer exists.", ephemeral=True)
            return

        try:
            new_password = await bot.incus.reinstall(
                self.vps_name, row["ram_mb"], row["cpu_cores"], row["disk_gb"], image
            )
            await bot.db.update_credentials(self.vps_name, new_password)
            ip = await bot.incus.get_ip(self.vps_name)
            if ip:
                await bot.db.update_ip(self.vps_name, ip)
            await bot.db.update_status(self.vps_name, "active")

            await interaction.followup.send(
                f"✅ **{self.vps_name}** reinstalled with **{label}**.\n"
                f"New root password sent to your DMs.",
                ephemeral=True,
            )
            try:
                await interaction.user.send(
                    f"🔁 **{self.vps_name}** was reinstalled with **{label}**.\n"
                    f"New root password: `{new_password}`"
                )
            except discord.Forbidden:
                pass
        except IncusError as e:
            await interaction.followup.send(f"❌ Reinstall failed: `{e}`", ephemeral=True)


class OSSelectView(discord.ui.View):
    def __init__(self, vps_name: str):
        super().__init__(timeout=120)
        self.add_item(OSSelect(vps_name))


class ManageView(discord.ui.View):
    """Buttons shown by `1manage` / `1myvps` for a single VPS."""

    def __init__(self, vps_name: str, owner_id: int):
        super().__init__(timeout=300)
        self.vps_name = vps_name
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "⛔ This isn't your VPS.", ephemeral=True
            )
            return False
        return True

    async def _refresh_message(self, interaction: discord.Interaction):
        bot = interaction.client
        row = await bot.db.get_vps(self.vps_name)
        if row is None:
            await interaction.edit_original_response(content="❌ VPS no longer exists.", embed=None, view=None)
            return
        await interaction.edit_original_response(embed=vps_embed(row), view=self)

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, emoji="▶️")
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        try:
            await bot.incus.start(self.vps_name)
            await interaction.followup.send(f"▶️ **{self.vps_name}** started.", ephemeral=True)
            await self._refresh_message(interaction)
        except IncusError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.danger, emoji="⏹️")
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        try:
            await bot.incus.stop(self.vps_name)
            await interaction.followup.send(f"⏹️ **{self.vps_name}** stopped.", ephemeral=True)
            await self._refresh_message(interaction)
        except IncusError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, emoji="🔄")
    async def restart(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        try:
            await bot.incus.restart(self.vps_name)
            await interaction.followup.send(f"🔄 **{self.vps_name}** restarted.", ephemeral=True)
            await self._refresh_message(interaction)
        except IncusError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)

    @discord.ui.button(label="Reinstall", style=discord.ButtonStyle.secondary, emoji="💽")
    async def reinstall(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            f"Choose an OS to reinstall **{self.vps_name}** with:",
            view=OSSelectView(self.vps_name),
            ephemeral=True,
        )

    @discord.ui.button(label="Regenerate SSH", style=discord.ButtonStyle.secondary, emoji="🔑")
    async def regenerate_ssh(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        try:
            password, tmate_ssh = await bot.incus.regenerate_ssh(self.vps_name)
            await bot.db.update_credentials(self.vps_name, password)
            await interaction.followup.send(
                "🔑 SSH credentials regenerated and sent to your DMs.", ephemeral=True
            )
            try:
                await interaction.user.send(
                    f"🔑 **{self.vps_name}** SSH credentials regenerated:\n"
                    f"Root password: `{password}`\n"
                    f"Tmate session: `{tmate_ssh}`"
                )
            except discord.Forbidden:
                await interaction.followup.send(
                    "⚠️ I couldn't DM you — please enable DMs from server members.",
                    ephemeral=True,
                )
        except IncusError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)

    @discord.ui.button(label="Refresh", style=discord.ButtonStyle.secondary, emoji="🔃")
    async def refresh(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        row = await bot.db.get_vps(self.vps_name)
        if row is None:
            await interaction.followup.send("❌ VPS no longer exists.", ephemeral=True)
            return
        running = await bot.incus.is_running(self.vps_name)
        ip = await bot.incus.get_ip(self.vps_name)
        if ip and ip != row["ip_address"]:
            await bot.db.update_ip(self.vps_name, ip)
            row = await bot.db.get_vps(self.vps_name)
        await interaction.followup.send(
            f"🔃 Refreshed. Container is currently **{'running' if running else 'stopped'}**.",
            ephemeral=True,
        )
        await interaction.edit_original_response(embed=vps_embed(row), view=self)
