import discord
from discord.ext import commands

import config
from cogs.views import vps_embed, ManageView
from cogs.admin import help_embed


class UserCommands(commands.Cog):
    """Commands available to every member for managing their own VPS."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _get_owned_vps(self, ctx: commands.Context):
        rows = await self.bot.db.list_vps(owner_id=ctx.author.id)
        return rows

    # ---------------------------------------------------------------- 1manage
    @commands.group(name="1manage", invoke_without_command=True)
    async def manage(self, ctx: commands.Context, vps: str = None):
        """1manage [vps] - open the control panel for one of your VPS instances."""
        rows = await self._get_owned_vps(ctx)
        if not rows:
            await ctx.reply("You don't own any VPS. Ask an admin to create one with `1create`.")
            return

        if vps:
            row = next((r for r in rows if r["name"] == vps), None)
            if row is None:
                await ctx.reply(f"❌ You don't own a VPS named `{vps}`.")
                return
        elif len(rows) == 1:
            row = rows[0]
        else:
            names = ", ".join(f"`{r['name']}`" for r in rows)
            await ctx.reply(f"You own multiple VPS. Specify one: {names}\nUsage: `1manage <vps>`")
            return

        view = ManageView(row["name"], row["owner_id"])
        await ctx.reply(embed=vps_embed(row), view=view)

    @manage.command(name="help")
    async def manage_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1manage", "1manage [vps]",
            "Opens an interactive control panel (Start / Stop / Restart / Reinstall / "
            "Regenerate SSH / Refresh) for a VPS you own. If you only own one VPS, "
            "the name can be omitted.",
            ["1manage", "1manage vps-alice-120301"],
        ))

    # ----------------------------------------------------------------- 1myvps
    @commands.group(name="1myvps", invoke_without_command=True)
    async def myvps(self, ctx: commands.Context):
        """1myvps - list every VPS you own."""
        rows = await self._get_owned_vps(ctx)
        if not rows:
            await ctx.reply("You don't own any VPS yet.")
            return

        status_emoji = {"active": "🟢", "suspended": "🟠", "expired": "🔴"}
        embed = discord.Embed(
            title=f"Your VPS ({len(rows)})",
            color=config.EMBED_COLOR,
        )
        for row in rows:
            embed.add_field(
                name=f"{status_emoji.get(row['status'], '⚪')} {row['name']}",
                value=(
                    f"{row['cpu_cores']} vCPU / {row['ram_mb']}MB / {row['disk_gb']}GB\n"
                    f"IP: {row['ip_address'] or 'N/A'}\n"
                    f"Expires: {row['expires_at'] or 'Never'}"
                ),
                inline=True,
            )
        embed.set_footer(text=f"Use 1manage <vps> to control one. | {config.BRAND_NAME}")
        await ctx.reply(embed=embed)

    @myvps.command(name="help")
    async def myvps_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1myvps", "1myvps",
            "Lists every VPS you currently own, along with resources, IP, and expiry date.",
            ["1myvps"],
        ))

    # ------------------------------------------------------------------ 1info
    @commands.group(name="1info", invoke_without_command=True)
    async def info(self, ctx: commands.Context, vps: str = None):
        """1info <vps> - show detailed info for a VPS you own (or any, if admin)."""
        if vps is None:
            await ctx.reply(embed=help_embed(
                "1info", "1info <vps>",
                "Shows detailed information (status, owner, OS, resources, IP, expiry) "
                "for a VPS you own. Admins can look up any VPS.",
                ["1info vps-alice-120301"],
            ))
            return
        row = await self.bot.db.get_vps(vps)
        if row is None:
            await ctx.reply(f"❌ No VPS named `{vps}` found.")
            return
        if row["owner_id"] != ctx.author.id and not ctx.author.guild_permissions.administrator:
            await ctx.reply("⛔ You don't own this VPS.")
            return
        await ctx.reply(embed=vps_embed(row))

    @info.command(name="help")
    async def info_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1info", "1info <vps>",
            "Shows detailed information (status, owner, OS, resources, IP, expiry) for a "
            "VPS you own. Admins can look up any VPS.",
            ["1info vps-alice-120301"],
        ))

    # ------------------------------------------------------------------ 1help
    @commands.command(name="1help")
    async def help_cmd(self, ctx: commands.Context):
        """1help - list all available commands."""
        embed = discord.Embed(
            title=f"{config.BRAND_NAME} VPS Manager - Help",
            description=(
                f"Powered by {config.VIRT_LABEL} on {config.CPU_LABEL} hardware.\n"
                "Tip: append `help` to any command (e.g. `1create help`) for detailed usage."
            ),
            color=config.EMBED_COLOR,
        )
        embed.add_field(
            name="User commands",
            value=(
                "`1manage [vps]` - control panel (start/stop/restart/reinstall/SSH)\n"
                "`1myvps` - list your VPS instances\n"
                "`1info <vps>` - detailed info\n"
                "`1help` - this message"
            ),
            inline=False,
        )
        if ctx.author.guild_permissions.administrator:
            embed.add_field(
                name="Admin commands",
                value=(
                    "`1create <user> <ram_mb> <cpu> <disk_gb> <expire>`\n"
                    "`1edit <user> <vps> [ram] [cpu] [disk] [expire]`\n"
                    "`1delete <vps>`\n"
                    "`1rename <vps> <new>`\n"
                    "`1suspend <vps>` / `1unsuspend <vps>`\n"
                    "`1list`"
                ),
                inline=False,
            )
        await ctx.reply(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(UserCommands(bot))
