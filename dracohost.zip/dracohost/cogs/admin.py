import discord
from discord.ext import commands

import config
from checks import is_admin
from incus_manager import IncusError
from cogs.views import vps_embed


def help_embed(title: str, usage: str, description: str, examples: list[str] | None = None) -> discord.Embed:
    embed = discord.Embed(
        title=f"📖 Help: {title}",
        description=description,
        color=config.EMBED_COLOR,
    )
    embed.add_field(name="Usage", value=f"`{usage}`", inline=False)
    if examples:
        embed.add_field(name="Examples", value="\n".join(f"`{e}`" for e in examples), inline=False)
    embed.set_footer(text=config.BRAND_NAME)
    return embed


class Admin(commands.Cog):
    """Admin-only VPS management commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ---------------------------------------------------------------- 1create
    @commands.group(name="1create", invoke_without_command=True)
    @is_admin()
    async def create(self, ctx: commands.Context, user: discord.User = None, ram: int = None,
                      cpu: int = None, disk: int = None, expire: str = "never"):
        """1create <user> <ram_mb> <cpu_cores> <disk_gb> <expire e.g. 30d|never>"""
        if user is None or ram is None or cpu is None or disk is None:
            await ctx.reply(embed=help_embed(
                "1create", "1create <user> <ram_mb> <cpu_cores> <disk_gb> [expire]",
                "Deploys a brand new Incus LXC VPS and assigns it to `<user>`. "
                "`expire` accepts `7d`, `4w`, `2m`, `1y`, or `never` (default).",
                ["1create @Alice 2048 2 40 30d", "1create @Bob 4096 4 80 never"],
            ))
            return
        name = f"vps-{user.name}-{discord.utils.utcnow().strftime('%H%M%S')}".lower()
        name = "".join(c for c in name if c.isalnum() or c == "-")[:63]

        msg = await ctx.reply(f"⏳ Deploying **{name}** on {config.VIRT_LABEL}...")
        try:
            password = await self.bot.incus.create_vps(name, ram, cpu, disk)
            ip = await self.bot.incus.get_ip(name)
            await self.bot.db.create_vps(
                name=name, owner_id=user.id, ram_mb=ram, cpu_cores=cpu, disk_gb=disk,
                os_image="images:ubuntu/24.04", expire_str=expire,
                ip_address=ip, root_password=password,
            )
        except (IncusError, ValueError) as e:
            await msg.edit(content=f"❌ Failed to create VPS: `{e}`")
            return

        row = await self.bot.db.get_vps(name)
        await msg.edit(content=f"✅ VPS **{name}** deployed for {user.mention}.", embed=vps_embed(row))

        try:
            await user.send(
                f"🎉 Your new VPS **{name}** is ready on {config.BRAND_NAME}!\n"
                f"IP: `{ip or 'pending'}`\nRoot password: `{password}`\n"
                f"Use `1manage` in the server to control it."
            )
        except discord.Forbidden:
            await ctx.send(f"⚠️ Couldn't DM {user.mention} — please ask them to enable DMs.")

    @create.command(name="help")
    async def create_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1create", "1create <user> <ram_mb> <cpu_cores> <disk_gb> [expire]",
            "Deploys a brand new Incus LXC VPS and assigns it to `<user>`. "
            "`expire` accepts `7d`, `4w`, `2m`, `1y`, or `never` (default).",
            ["1create @Alice 2048 2 40 30d", "1create @Bob 4096 4 80 never"],
        ))

    # ------------------------------------------------------------------ 1edit
    @commands.group(name="1edit", invoke_without_command=True)
    @is_admin()
    async def edit(self, ctx: commands.Context, user: discord.User = None, vps: str = None,
                    ram: int = None, cpu: int = None, disk: int = None, expire: str = None):
        """1edit <user> <vps> [ram] [cpu] [disk] [expire] - reassign owner and/or resize."""
        if user is None or vps is None:
            await ctx.reply(embed=help_embed(
                "1edit", "1edit <user> <vps> [ram] [cpu] [disk] [expire]",
                "Reassigns `<vps>` to `<user>` and optionally resizes it or changes its expiry. "
                "Omit any resize argument to leave it unchanged.",
                ["1edit @Alice vps-alice-120301 4096 4 80", "1edit @Bob vps-bob-093211"],
            ))
            return
        row = await self.bot.db.get_vps(vps)
        if row is None:
            await ctx.reply(f"❌ No VPS named `{vps}` found.")
            return

        await self.bot.db.update_owner(vps, user.id)
        try:
            await self.bot.db.update_resources(vps, ram_mb=ram, cpu_cores=cpu,
                                                disk_gb=disk, expire_str=expire)
            if ram or cpu or disk:
                new_row = await self.bot.db.get_vps(vps)
                await self.bot.incus.set_limits(
                    vps, new_row["ram_mb"], new_row["cpu_cores"], new_row["disk_gb"]
                )
        except (IncusError, ValueError) as e:
            await ctx.reply(f"⚠️ Ownership updated, but resize failed: `{e}`")
            return

        row = await self.bot.db.get_vps(vps)
        await ctx.reply(f"✅ **{vps}** updated.", embed=vps_embed(row))

    @edit.command(name="help")
    async def edit_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1edit", "1edit <user> <vps> [ram] [cpu] [disk] [expire]",
            "Reassigns `<vps>` to `<user>` and optionally resizes it or changes its expiry.",
            ["1edit @Alice vps-alice-120301 4096 4 80", "1edit @Bob vps-bob-093211"],
        ))

    # ---------------------------------------------------------------- 1delete
    @commands.group(name="1delete", invoke_without_command=True)
    @is_admin()
    async def delete(self, ctx: commands.Context, vps: str = None):
        """1delete <vps>"""
        if vps is None:
            await ctx.reply(embed=help_embed(
                "1delete", "1delete <vps>",
                "Permanently destroys the LXC container and removes its database record. "
                "This cannot be undone.",
                ["1delete vps-alice-120301"],
            ))
            return
        row = await self.bot.db.get_vps(vps)
        if row is None:
            await ctx.reply(f"❌ No VPS named `{vps}` found.")
            return
        try:
            await self.bot.incus.delete_vps(vps)
        except IncusError as e:
            await ctx.reply(f"⚠️ Could not delete container on host: `{e}` — removing DB record anyway.")
        await self.bot.db.delete_vps(vps)
        await ctx.reply(f"🗑️ **{vps}** has been deleted.")

    @delete.command(name="help")
    async def delete_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1delete", "1delete <vps>",
            "Permanently destroys the LXC container and removes its database record. "
            "This cannot be undone.",
            ["1delete vps-alice-120301"],
        ))

    # ---------------------------------------------------------------- 1rename
    @commands.group(name="1rename", invoke_without_command=True)
    @is_admin()
    async def rename(self, ctx: commands.Context, vps: str = None, new_name: str = None):
        """1rename <vps> <new>"""
        if vps is None or new_name is None:
            await ctx.reply(embed=help_embed(
                "1rename", "1rename <vps> <new_name>",
                "Renames a VPS container both on the Incus host and in the database.",
                ["1rename vps-alice-120301 alice-web-server"],
            ))
            return
        row = await self.bot.db.get_vps(vps)
        if row is None:
            await ctx.reply(f"❌ No VPS named `{vps}` found.")
            return
        try:
            await self.bot.incus.rename_vps(vps, new_name)
        except IncusError as e:
            await ctx.reply(f"❌ Rename failed on host: `{e}`")
            return
        await self.bot.db.rename_vps(vps, new_name)
        await ctx.reply(f"✏️ **{vps}** renamed to **{new_name}**.")

    @rename.command(name="help")
    async def rename_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1rename", "1rename <vps> <new_name>",
            "Renames a VPS container both on the Incus host and in the database.",
            ["1rename vps-alice-120301 alice-web-server"],
        ))

    # --------------------------------------------------------------- 1suspend
    @commands.group(name="1suspend", invoke_without_command=True)
    @is_admin()
    async def suspend(self, ctx: commands.Context, vps: str = None):
        """1suspend <vps>"""
        if vps is None:
            await ctx.reply(embed=help_embed(
                "1suspend", "1suspend <vps>",
                "Pauses (freezes) a container so its owner can no longer use it, "
                "without deleting any data.",
                ["1suspend vps-alice-120301"],
            ))
            return
        row = await self.bot.db.get_vps(vps)
        if row is None:
            await ctx.reply(f"❌ No VPS named `{vps}` found.")
            return
        try:
            await self.bot.incus.suspend(vps)
        except IncusError as e:
            await ctx.reply(f"❌ Suspend failed: `{e}`")
            return
        await self.bot.db.update_status(vps, "suspended")
        await ctx.reply(f"🟠 **{vps}** suspended.")

    @suspend.command(name="help")
    async def suspend_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1suspend", "1suspend <vps>",
            "Pauses (freezes) a container so its owner can no longer use it, without deleting any data.",
            ["1suspend vps-alice-120301"],
        ))

    # ------------------------------------------------------------- 1unsuspend
    @commands.group(name="1unsuspend", invoke_without_command=True)
    @is_admin()
    async def unsuspend(self, ctx: commands.Context, vps: str = None):
        """1unsuspend <vps>"""
        if vps is None:
            await ctx.reply(embed=help_embed(
                "1unsuspend", "1unsuspend <vps>",
                "Resumes a previously suspended container and marks it active again.",
                ["1unsuspend vps-alice-120301"],
            ))
            return
        row = await self.bot.db.get_vps(vps)
        if row is None:
            await ctx.reply(f"❌ No VPS named `{vps}` found.")
            return
        try:
            await self.bot.incus.unsuspend(vps)
        except IncusError as e:
            await ctx.reply(f"❌ Unsuspend failed: `{e}`")
            return
        await self.bot.db.update_status(vps, "active")
        await ctx.reply(f"🟢 **{vps}** unsuspended.")

    @unsuspend.command(name="help")
    async def unsuspend_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1unsuspend", "1unsuspend <vps>",
            "Resumes a previously suspended container and marks it active again.",
            ["1unsuspend vps-alice-120301"],
        ))

    # ------------------------------------------------------------------ 1list
    @commands.group(name="1list", invoke_without_command=True)
    @is_admin()
    async def list_all(self, ctx: commands.Context):
        """1list - list every VPS on the host."""
        rows = await self.bot.db.list_vps()
        if not rows:
            await ctx.reply("No VPS instances found.")
            return

        embed = discord.Embed(
            title=f"{config.BRAND_NAME} - All VPS ({len(rows)})",
            color=config.EMBED_COLOR,
        )
        status_emoji = {"active": "🟢", "suspended": "🟠", "expired": "🔴"}
        for row in rows[:25]:
            embed.add_field(
                name=f"{status_emoji.get(row['status'], '⚪')} {row['name']}",
                value=(
                    f"Owner: <@{row['owner_id']}>\n"
                    f"{row['cpu_cores']} vCPU / {row['ram_mb']}MB / {row['disk_gb']}GB\n"
                    f"IP: {row['ip_address'] or 'N/A'}"
                ),
                inline=True,
            )
        if len(rows) > 25:
            embed.set_footer(text=f"Showing 25 of {len(rows)} — refine with 1info <vps>.")
        else:
            embed.set_footer(text=config.BRAND_NAME)
        await ctx.reply(embed=embed)

    @list_all.command(name="help")
    async def list_help(self, ctx: commands.Context):
        await ctx.reply(embed=help_embed(
            "1list", "1list", "Lists every VPS on the host, with owner, resources, and IP.",
            ["1list"],
        ))


async def setup(bot: commands.Bot):
    await bot.add_cog(Admin(bot))
