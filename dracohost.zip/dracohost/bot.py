"""
bot.py - DracoHost VPS Manager
Entry point for the Discord.py bot that manages Incus LXC containers.
"""

import asyncio
import logging

import discord
from discord.ext import commands, tasks

import config
from db import Database
from incus_manager import IncusManager, IncusError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
log = logging.getLogger("dracohost")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True


class DracoHostBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or(config.COMMAND_PREFIX),
            intents=intents,
            help_command=None,
        )
        self.db = Database(config.DATABASE_PATH)
        self.incus = IncusManager(
            network=config.INCUS_NETWORK,
            storage_pool=config.INCUS_STORAGE_POOL,
        )

    async def setup_hook(self):
        await self.db.connect()
        await self.load_extension("cogs.admin")
        await self.load_extension("cogs.user")

        if config.GUILD_ID:
            guild = discord.Object(id=int(config.GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            log.info("Slash commands synced to guild %s", config.GUILD_ID)
        else:
            await self.tree.sync()
            log.info("Slash commands synced globally")

        self.expiry_check.start()

    @tasks.loop(minutes=config.EXPIRY_CHECK_INTERVAL_MINUTES)
    async def expiry_check(self):
        """Suspends any VPS whose expiry date has passed."""
        try:
            expired = await self.db.get_expired()
        except Exception:
            log.exception("Failed to query expired VPS")
            return

        for row in expired:
            try:
                await self.incus.suspend(row["name"])
                await self.db.update_status(row["name"], "expired")
                log.info("Suspended expired VPS %s (owner %s)", row["name"], row["owner_id"])
                owner = self.get_user(row["owner_id"]) or await self.fetch_user(row["owner_id"])
                if owner:
                    await owner.send(
                        f"⏰ Your VPS **{row['name']}** has expired and been suspended. "
                        f"Contact an admin to renew it."
                    )
            except (IncusError, discord.Forbidden, discord.HTTPException):
                log.exception("Failed to process expired VPS %s", row["name"])

    @expiry_check.before_loop
    async def before_expiry_check(self):
        await self.wait_until_ready()

    async def close(self):
        await self.db.close()
        await super().close()


bot = DracoHostBot()


@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching, name="over your VPS | DracoHost"
        )
    )


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.reply(f"⚠️ Missing argument: `{error.param.name}`. Check `1help`.")
        return
    if isinstance(error, commands.CheckFailure):
        await ctx.reply("⛔ You don't have permission to use this command.")
        return
    log.exception("Unhandled command error", exc_info=error)
    await ctx.reply(f"❌ Something went wrong: `{error}`")


def main():
    if not config.DISCORD_TOKEN:
        raise SystemExit("DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.")
    asyncio.run(bot.start(config.DISCORD_TOKEN))


if __name__ == "__main__":
    main()
