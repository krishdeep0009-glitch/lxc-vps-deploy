import os
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
GUILD_ID = os.getenv("GUILD_ID") or None
ADMIN_ROLE_IDS = {
    int(x) for x in os.getenv("ADMIN_ROLE_IDS", "").split(",") if x.strip().isdigit()
}
DATABASE_PATH = os.getenv("DATABASE_PATH", "dracohost.db")
# All commands are literally named "1create", "1list", etc. (per spec), so the
# prefix itself is empty - the leading "1" lives in the command name.
COMMAND_PREFIX = os.getenv("COMMAND_PREFIX", "")
INCUS_NETWORK = os.getenv("INCUS_NETWORK", "incusbr0")
INCUS_STORAGE_POOL = os.getenv("INCUS_STORAGE_POOL", "default")
EXPIRY_CHECK_INTERVAL_MINUTES = int(os.getenv("EXPIRY_CHECK_INTERVAL_MINUTES", "15"))

# Branding
BRAND_NAME = "DracoHost"
CPU_LABEL = "Intel® Xeon®"
VIRT_LABEL = "Incus LXC"
EMBED_COLOR = 0x2B2D31
