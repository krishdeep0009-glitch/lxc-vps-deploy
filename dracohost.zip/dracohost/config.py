import os
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# The only three things you need to set in .env: your bot token, the role
# IDs allowed to run admin commands, and/or specific user IDs allowed to run
# admin commands regardless of role. Everything else below is a sane default
# — edit it directly in this file if you need to change it.
# ---------------------------------------------------------------------------
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")

ADMIN_ROLE_IDS = {
    int(x) for x in os.getenv("ADMIN_ROLE_IDS", "").split(",") if x.strip().isdigit()
}
ADMIN_IDS = {
    int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()
}

# ---------------------------------------------------------------------------
# Everything below is a hardcoded default (no .env entry needed).
# ---------------------------------------------------------------------------
GUILD_ID = None  # set to an int to sync slash commands instantly to one guild
DATABASE_PATH = "dracohost.db"
# All commands are literally named "1create", "1list", etc. (per spec), so the
# prefix itself is empty - the leading "1" lives in the command name.
COMMAND_PREFIX = ""
INCUS_NETWORK = "incusbr0"
INCUS_STORAGE_POOL = "default"
EXPIRY_CHECK_INTERVAL_MINUTES = 15

# Branding
BRAND_NAME = "DracoHost"
CPU_LABEL = "Intel® Xeon®"
VIRT_LABEL = "Incus LXC"
EMBED_COLOR = 0x2B2D31
