"""
db.py - SQLite persistence layer for DracoHost VPS Manager.

Stores every VPS record: owner, resources, OS, IP, root password,
expiry date and status (active / suspended / expired).
"""

import datetime
import aiosqlite

SCHEMA = """
CREATE TABLE IF NOT EXISTS vps (
    name        TEXT PRIMARY KEY,
    owner_id    INTEGER NOT NULL,
    ram_mb      INTEGER NOT NULL,
    cpu_cores   INTEGER NOT NULL,
    disk_gb     INTEGER NOT NULL,
    os_image    TEXT NOT NULL DEFAULT 'ubuntu/24.04',
    ip_address  TEXT,
    root_password TEXT,
    status      TEXT NOT NULL DEFAULT 'active',   -- active | suspended | expired
    created_at  TEXT NOT NULL,
    expires_at  TEXT
);

CREATE INDEX IF NOT EXISTS idx_vps_owner ON vps(owner_id);
"""


class Database:
    def __init__(self, path: str):
        self.path = path
        self._conn: aiosqlite.Connection | None = None

    async def connect(self):
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.executescript(SCHEMA)
        await self._conn.commit()

    async def close(self):
        if self._conn:
            await self._conn.close()

    # ---------- helpers ----------
    @staticmethod
    def _now() -> str:
        return datetime.datetime.utcnow().isoformat()

    @staticmethod
    def _expiry_to_iso(expire_str: str) -> str | None:
        """Convert '7d', '30d', '1m', '1y', 'never' into an ISO date string (or None)."""
        if not expire_str or expire_str.lower() == "never":
            return None
        unit = expire_str[-1].lower()
        try:
            amount = int(expire_str[:-1])
        except ValueError:
            raise ValueError("Expiry must look like 7d, 4w, 1m, 1y, or 'never'.")

        now = datetime.datetime.utcnow()
        if unit == "d":
            delta = datetime.timedelta(days=amount)
        elif unit == "w":
            delta = datetime.timedelta(weeks=amount)
        elif unit == "m":
            delta = datetime.timedelta(days=amount * 30)
        elif unit == "y":
            delta = datetime.timedelta(days=amount * 365)
        else:
            raise ValueError("Expiry unit must be one of d/w/m/y (e.g. 7d, 4w, 2m, 1y).")
        return (now + delta).isoformat()

    # ---------- CRUD ----------
    async def create_vps(self, name, owner_id, ram_mb, cpu_cores, disk_gb,
                          os_image, expire_str, ip_address=None, root_password=None):
        expires_at = self._expiry_to_iso(expire_str)
        await self._conn.execute(
            """INSERT INTO vps
               (name, owner_id, ram_mb, cpu_cores, disk_gb, os_image,
                ip_address, root_password, status, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)""",
            (name, owner_id, ram_mb, cpu_cores, disk_gb, os_image,
             ip_address, root_password, self._now(), expires_at),
        )
        await self._conn.commit()

    async def get_vps(self, name):
        cur = await self._conn.execute("SELECT * FROM vps WHERE name = ?", (name,))
        return await cur.fetchone()

    async def list_vps(self, owner_id=None):
        if owner_id is not None:
            cur = await self._conn.execute(
                "SELECT * FROM vps WHERE owner_id = ? ORDER BY created_at DESC", (owner_id,)
            )
        else:
            cur = await self._conn.execute("SELECT * FROM vps ORDER BY created_at DESC")
        return await cur.fetchall()

    async def update_status(self, name, status):
        await self._conn.execute("UPDATE vps SET status = ? WHERE name = ?", (status, name))
        await self._conn.commit()

    async def update_owner(self, name, new_owner_id):
        await self._conn.execute(
            "UPDATE vps SET owner_id = ? WHERE name = ?", (new_owner_id, name)
        )
        await self._conn.commit()

    async def update_credentials(self, name, root_password):
        await self._conn.execute(
            "UPDATE vps SET root_password = ? WHERE name = ?", (root_password, name)
        )
        await self._conn.commit()

    async def update_ip(self, name, ip_address):
        await self._conn.execute(
            "UPDATE vps SET ip_address = ? WHERE name = ?", (ip_address, name)
        )
        await self._conn.commit()

    async def rename_vps(self, old_name, new_name):
        await self._conn.execute(
            "UPDATE vps SET name = ? WHERE name = ?", (new_name, old_name)
        )
        await self._conn.commit()

    async def update_resources(self, name, ram_mb=None, cpu_cores=None, disk_gb=None,
                                expire_str=None):
        fields, values = [], []
        if ram_mb is not None:
            fields.append("ram_mb = ?"); values.append(ram_mb)
        if cpu_cores is not None:
            fields.append("cpu_cores = ?"); values.append(cpu_cores)
        if disk_gb is not None:
            fields.append("disk_gb = ?"); values.append(disk_gb)
        if expire_str is not None:
            fields.append("expires_at = ?"); values.append(self._expiry_to_iso(expire_str))
        if not fields:
            return
        values.append(name)
        await self._conn.execute(f"UPDATE vps SET {', '.join(fields)} WHERE name = ?", values)
        await self._conn.commit()

    async def delete_vps(self, name):
        await self._conn.execute("DELETE FROM vps WHERE name = ?", (name,))
        await self._conn.commit()

    async def get_expired(self):
        now = self._now()
        cur = await self._conn.execute(
            "SELECT * FROM vps WHERE expires_at IS NOT NULL AND expires_at <= ? "
            "AND status != 'expired'",
            (now,),
        )
        return await cur.fetchall()
