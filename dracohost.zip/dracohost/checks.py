import config
from discord.ext import commands


def is_admin():
    """Allows server administrators or anyone holding a configured admin role."""

    async def predicate(ctx: commands.Context) -> bool:
        if ctx.author.id in config.ADMIN_IDS:
            return True
        if ctx.author.guild_permissions.administrator:
            return True
        if config.ADMIN_ROLE_IDS:
            user_role_ids = {role.id for role in getattr(ctx.author, "roles", [])}
            if user_role_ids & config.ADMIN_ROLE_IDS:
                return True
            return False
        # No admin roles configured -> fall back to Manage Server permission.
        return ctx.author.guild_permissions.manage_guild

    return commands.check(predicate)
